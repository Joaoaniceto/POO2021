import java.time.LocalDateTime;

public class Encomenda {
    
    private String nome;
    private String nif;
    private String morada;
    private int nrEncomenda;
    private LocalDateTime data;
    private LinhaEncomenda [] linhasEncomenda;
    private int ocupacao;
    private static int capacidade_inicial=10;
    
    
    
    /**
     * Construtores da classe Encomenda:
     * Omissão,Parametrizado e Cópia.
     */
    
    public Encomenda (){
        this.nome="";
        this.nif="";
        this.morada="";
        this.nrEncomenda=0;
        this.data=null;
        this.ocupacao=0;
        this.linhasEncomenda=new LinhaEncomenda[capacidade_inicial];
    }
    
    public Encomenda(String nome,String nif,String morada,int nrEncomenda,LocalDateTime data,int capacidade){
        this.nome=nome;
        this.nif=nif;
        this.morada=morada;
        this.nrEncomenda=nrEncomenda;
        this.data=data;
        this.ocupacao=0;
        this.linhasEncomenda=new LinhaEncomenda[capacidade];
    }
    
    public Encomenda(Encomenda l){
        this.nome=l.getNome();
        this.nif=l.getNif();
        this.morada=l.getMorada();
        this.nrEncomenda=l.getNrencomenda();
        this.data=l.getData();
        this.linhasEncomenda=l.getLinhas();
    }
    
    /**
     * Getters e Setters
     */
    
    public String getNome(){
        return this.nome;
    }
    
    public String getNif(){
        return this.nif;
    }
    
    public String getMorada(){
        return this.morada;
    }
    
    public int getNrencomenda(){
        return this.nrEncomenda;
    }
    
    public LocalDateTime getData(){
        return this.data;
    }
    
    /**
     * Possível perda de encapsulamento devido a partilha de endereços.
     */
    public LinhaEncomenda[] getLinhas(){
        return this.linhasEncomenda;
    }
    public int getOcupacao(){
        return this.ocupacao;
    }
    
    public void setNome(String nome){
        this.nome=nome;
    }
    
    public void setNif(String nif){
        this.nif=nif;
    }
    
    public void setMorada(String morada){
        this.morada=morada;
    }
    
    public void setNrencomenda(int nrEncomenda){
        this.nrEncomenda=nrEncomenda;
    }
    
    public void setData(LocalDateTime data){
        this.data=data;
    }
    
    public void setOcupacao(int ocupacao){
        this.ocupacao=ocupacao;
    }
    
    //Método equals
    public boolean equals (Object o){
        if(this==o)
         return true;
        else
           if(o==null||this.getClass()!=o.getClass())
           return false;
        Encomenda l=(Encomenda) o;
        return (this.nome.equals(l.getNome()) &&
                this.nif.equals(l.getNif()) &&
                this.morada.equals(l.getMorada())&&
                this.nrEncomenda==l.getNrencomenda()&&
                this.data.equals(l.getData()) &&
                this.linhasEncomenda.equals(l.getLinhas())&&
                this.ocupacao==l.getOcupacao());
            }
                
    //Método Clone
    
    public Encomenda clone(){
        return new Encomenda (this);
    }
    
    //Método toString(Como imprimir o array)
    public String toString(){
        StringBuilder sb=new StringBuilder();
        sb.append("Nome: ");
        sb.append(this.nome+"\n");
        sb.append("NIF: ");
        sb.append(this.nif+"\n");
        sb.append("Morada: ");
        sb.append(this.morada+"\n");
        sb.append("Nº da encomenda: ");
        sb.append(this.nrEncomenda+"\n");
        sb.append("Data da encomenda: ");
        sb.append(this.data+"\n");
        sb.append("Ocupação: ");
        sb.append(this.ocupacao+"\n");
        
        return sb.toString();
    }
    
    /**
     * Método que calcula o valor total de uma encomenda.
     */
    public double calculaValorTotal(){
        double total=0;
        for(int i=0;i<this.ocupacao;i++)
         total+=linhasEncomenda[i].calculaValorLinhaEnc();
         return total;
    }
    /**
     * Método que determina o valor total dos descontos obtidos nos diversos
     * produtos encomendados.
     */
    
    public double calculaValorDesconto(){
          double total=0;
        for(int i=0;i<this.ocupacao;i++)
         total+=linhasEncomenda[i].calculaValorDesconto();
         return total;
    }
    
    /**
     * Método que determina o número total de produtos
     */
    
    int numeroTotalProdutos(){
        int total=0;
          for(int i=0;i<this.ocupacao;i++)
            total+=linhasEncomenda[i].getQuantidade();
            
            return total;
        }
        
    /**
     * Método que determina se um produto vai ser encomendado.
     */  
    public boolean existeProdutoEncomenda( String refProd){
        boolean flag=false;
         for(int i=0;i<this.ocupacao&&!flag;i++)
             if(this.linhasEncomenda[i].getReferencia()==refProd)
              flag=true;
           return flag;
       }
    /**
     * Método que adiciona uma nova linha de encomenda.
     */   
    public void adicionaLinha(LinhaEncomenda linha){
        if(this.ocupacao<this.capacidade_inicial){
           this.linhasEncomenda[this.ocupacao]=linha;
             setOcupacao(this.ocupacao+1);
            }
        }
    /**
     * Método que remove uma linha de encomenda dada a referência do 
     * produto.(Acho que não funciona)
     */    
    public void removeProduto(String codProd){
        boolean flag=false;
        int i;
        for(i=0;i<this.ocupacao&&!flag;i++)
           if(this.linhasEncomenda[i].getReferencia()==codProd)
             flag=true;
              if(i!=this.ocupacao){
             int shift=this.ocupacao-i-1;
                if(shift>0)
            System.arraycopy(this.linhasEncomenda,i+1,this.linhasEncomenda,
                             i,shift);
                  setOcupacao(this.ocupacao-1);
                }
             
        
    }
    
                 }      
   